<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class feedback_controller extends Controller
{
    //
}
