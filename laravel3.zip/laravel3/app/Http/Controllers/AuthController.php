<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function register(Request $request) {


        $fields = $request->validate([
            'your_email'=>'required|string',
            'your_password'=>'required|string',
            'name' => 'required|string',
            'email' => 'required|string|unique:users,email',
            'password' => 'required|string|confirmed',
            'role' => 'required',
            'emirate_id' => 'required|string',
            'employ_number' => 'required|string',
            'visa_expiry_date' => 'required|string'

        ]);

        //check email
        
        $user = User::where('email', $fields['your_email'])->first();
        $role = User::select('role')->where('email',$fields['your_email'])->get();
        //echo $user['name'];
        //echo $role[0];
        
        // Check password
        if(!$user || !Hash::check($fields['your_password'], $user->password) && $role=='system_admin' ) {

            return response([
                'message' => 'Bad creds'
            ], 401);
        }
        elseif (strpos($role, 'system_admin') !== false ) {



            $user = User::create([
                'name' => $fields['name'],
                'email' => $fields['email'],
                'password' => bcrypt($fields['password']),
                'role'=> $fields['role'],
                'emirate_id'=> $fields['emirate_id'],
                'employ_number'=> $fields['employ_number'],
                'visa_expiry_date'=> $fields['visa_expiry_date']
            ]);

    

        $token = $user->createToken('myapptoken')->plainTextToken;

        $response = [
            'user' => $user,
            'token' => $token
        ];
    

        return response($response, 201);
        
    }
    else
      {
        return "You are not system admin";
         
      }
    
    }

    public function login(Request $request) {
        $fields = $request->validate([
            'email' => 'required|string',
            'password' => 'required|string'
        ]);

        // Check email
        $user = User::where('email', $fields['email'])->first();

        // Check password
        if(!$user || !Hash::check($fields['password'], $user->password)) {
            return response([
                'message' => 'Bad creds'
            ], 401);
        }

        $token = $user->createToken('myapptoken')->plainTextToken;

        $response = [
            'user' => $user,
            'token' => $token
        ];

        return response($response, 201);
    }

    public function logout(Request $request) {
        auth()->user()->tokens()->delete();

        return [
            'message' => 'Logged out'
        ];
    }
}
  