<?php

namespace App\Http\Controllers;
use App\Models\Project;
use App\Models\attendance;
use App\Models\sick_leave;
use App\Models\feedback;
use App\Models\team;
use App\Models\User;
use App\Models\document;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;

class ProjectController extends Controller
{
    public function show_all_projects(){
        return Project::all();
    }

    public function create_project(Request $request){

        $request->validate([
            'your_email'=>'required',
            'your_password'=>'required'
        ]);
        $user = User::where('email', $request['your_email'])->first();
        $role = User::select('role')->where('email',$request['your_email'])->get();
        //echo $user['name'];
        //echo $role[0];
        
        // Check password
        if(!$user || !Hash::check($request['your_password'], $user->password) && $role=='system_admin' ) {

            return response([
                'message' => 'Bad creds'
            ], 401);
        }
        elseif (strpos($role, 'system_admin') !== false ) {

        $request->validate([
            'Project_Name'=>'required',
        'Details'=>'required',
        'Deadline'=>'required',
        'User_assigned'=>'required'
        ]);
        return Project::create($request->all());
    }
    else {
        return 'you are not system admin';
    }
    }

    //show specific project
    public function show_project_by_id($id){
        return Project::find($id);
    }

    public function update_project(Request $request, $id){
        $request->validate([
            'your_email'=>'required',
            'your_password'=>'required'
        ]);
        $user = User::where('email', $request['your_email'])->first();
        $role = User::select('role')->where('email',$request['your_email'])->get();
        //echo $user['name'];
        //echo $role[0];
        
        // Check password
        if(!$user || !Hash::check($request['your_password'], $user->password) && $role=='system_admin' ) {

            return response([
                'message' => 'Bad creds'
            ], 401);
        }
        elseif (strpos($role, 'system_admin') !== false ) {

        $project=Project::find($id);
        $project->update($request->all());
        return $project;
        }
        else {
            return 'you are not syatem admin';
        }

    }

    public function delete_project(Request $request, $id){
        $request->validate([
            'your_email'=>'required',
            'your_password'=>'required'
        ]);
        $user = User::where('email', $request['your_email'])->first();
        $role = User::select('role')->where('email',$request['your_email'])->get();
        //echo $user['name'];
        //echo $role[0];
        
        // Check password
        if(!$user || !Hash::check($request['your_password'], $user->password) && $role=='system_admin' ) {

            return response([
                'message' => 'Bad creds'
            ], 401);
        }
        elseif (strpos($role, 'system_admin') !== false ) {
        return Project::destroy($id);
        }
        else {
            return 'you are not system admin';
        }
    }


    public function search_project(Request $request, $project_name){
        $request->validate([
            'your_email'=>'required',
            'your_password'=>'required'
        ]);
        $user = User::where('email', $request['your_email'])->first();
        $role = User::select('role')->where('email',$request['your_email'])->get();
        //echo $user['name'];
        //echo $role[0];
        
        // Check password
        if(!$user || !Hash::check($request['your_password'], $user->password) && $role=='system_admin' ) {

            return response([
                'message' => 'Bad creds'
            ], 401);
        }
        elseif (strpos($role, 'system_admin') !== false ) {

        return Project::where('Project_Name', 'like','%'.$project_name.'%')->get();

        }

        else {
            return 'you are not system admin';
        }
    }


    public function clock_attendance_in(Request $request){
        $request->validate([
            'name'=>'required',
        'employee_id'=>'required',
        'time_in'=>'required',
        'time_out'

        ]);
        return attendance::create($request->all());
    }

    public function clock_attendance_out(Request $request){
        $request->validate([
            'name'=>'required',
            'employee_id'=>'required',
            'time_in',
            'time_out'=>'required'
        ]);
        return attendance::create($request->all());
    }

    public function create_feedback(Request $request){
        $request->validate([
            'name'=>'required',
        'employee_id'=>'required',
        'feedback_details'=>'required'
        ]);
        return feedback::create($request->all());
    }


    public function create_sick_leave(Request $request){
        $request->validate([
            'name'=>'required',
        'employee_id'=>'required',
        'sick_leave_details'=>'required',
        'sick_leave_date' => 'required'
        ]);
        return sick_leave::create($request->all());
    }


    public function assign_employee_to_team(Request $request){
        $request->validate([
            'team_name'=>'required',
        'employee_id'=>'required'
        ]);
        return team::create($request->all());
    }

    public function view_all_employee(Request $request){
        $request->validate([
            'your_email'=>'required',
            'your_password'=>'required'
        ]);
        $user = User::where('email', $request['your_email'])->first();
        $role = User::select('role')->where('email',$request['your_email'])->get();
        //echo $user['name'];
        //echo $role[0];
        
        // Check password
        if(!$user || !Hash::check($request['your_password'], $user->password) && $role=='system_admin' ) {

            return response([
                'message' => 'Bad creds'
            ], 401);
        }
        elseif (strpos($role, 'system_admin') !== false ) {

        return User::all();

        }
        else
        {
            return 'you are not system admim';
        }
        
    }


    public function upload_document(Request $request){
        $request->validate([
            'document_name'=>'required',
        'document_uploaded_by'=>'required'
        ]);
        return document::create($request->all());
    }


    


}
