<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class sick_leave_controller extends Controller
{
    //
}
