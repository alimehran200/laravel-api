<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class attendance_controller extends Controller
{
    //
}
