<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class sick_leave extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $fillable =[
        'name',
        'employee_id',
        'sick_leave_details',
        'sick_leave_date'
    ];
}
