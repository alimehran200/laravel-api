<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Models\Project;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\AuthController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('/login',[AuthController::class, 'login']);



//protected
Route::group(['middleware'=>['auth:sanctum']], function() {
    Route::post('/search_project/{project_name}',[ProjectController::class, 'search_project']);
    Route::post('/register',[AuthController::class, 'register']);
    Route::post('/logout',[AuthController::class, 'logout']);
    Route::post('/clock_attendance_in',[ProjectController::class, 'clock_attendance_in']);
    Route::post('/clock_attendance_out',[ProjectController::class, 'clock_attendance_out']);
    Route::post('/create_feedback',[ProjectController::class, 'create_feedback']);
    Route::post('/create_sick_leave',[ProjectController::class, 'create_sick_leave']);
    Route::post('/assign_employee_to_team',[ProjectController::class, 'assign_employee_to_team']);
    Route::post('/create_project',[ProjectController::class, 'create_project']);
    Route::post('/upload_document',[ProjectController::class, 'upload_document']);


    Route::post('/show_all_projects',[ProjectController::class, 'show_all_projects']);
Route::post('/show_project_by_id/{id}',[ProjectController::class, 'show_project_by_id']);
Route::post('/update_project/{id}',[ProjectController::class, 'update_project']);
Route::post('/delete_project/{id}',[ProjectController::class, 'delete_project']);

});





Route::post('/view_all_employee',[ProjectController::class, 'view_all_employee']);
//Route::get('/search_project/{project_name}',[ProjectController::class, 'search_project']);

// Route::post('/add_project',function(){
//     return Project::create([
//         'Project Name'=>'laravel',
//         'Details'=>'This is the details of the project',
//         'Deadline'=>'This is the deadline of the project',
//         'User_assigned'=>'user1'
//     ]);
// });